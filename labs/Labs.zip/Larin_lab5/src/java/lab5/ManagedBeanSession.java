/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab5;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author stu-ist109
 */

@ManagedBean(name="ManagedBeanSession")
@SessionScoped


public class ManagedBeanSession {

    /** Creates a new instance of ManagedBeanSession */
    public ManagedBeanSession() {
    }

}
