
public class ManagedBeanSession {
    private int op_counter;

    public ManagedBeanSession() {
    }

    public int getOp_counter() {
        return op_counter;
    }

    public void setOp_counter(int op_counter) {
        this.op_counter = op_counter;
    }

}
