/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package laba2;

/**
 *
 * @author ilya270392
 */
public class Sorevnovania {


private  int ID_Sorevnovania ;
private String Strana;

    /**
     * @return the ID_Sorevnovania
     */
    public int getID_Sorevnovania() {
        return ID_Sorevnovania;
    }

    /**
     * @param ID_Sorevnovania the ID_Sorevnovania to set
     */
    public void setID_Sorevnovania(int ID_Sorevnovania) {
        this.ID_Sorevnovania = ID_Sorevnovania;
    }

    /**
     * @return the Strana
     */
    public String getStrana() {
        return Strana;
    }

    /**
     * @param Strana the Strana to set
     */
    public void setStrana(String Strana) {
        this.Strana = Strana;
    }
//private  Chislo_Sorevnovania ;

//private  Data_Rogdenia;




}
