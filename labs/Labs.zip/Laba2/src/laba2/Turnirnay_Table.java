/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package laba2;

/**
 *
 * @author ilya270392
 */
public class Turnirnay_Table {

    private int ID_Table;
    private int Zanatoe_Mesto;
    private int id_Sorevnovania_;
    private int id_Sportsmena_;

    /**
     * @return the ID_Table
     */
    public int getID_Table() {
        return ID_Table;
    }

    /**
     * @param ID_Table the ID_Table to set
     */
    public void setID_Table(int ID_Table) {
        this.ID_Table = ID_Table;
    }

    /**
     * @return the Zanatoe_Mesto
     */
    public int getZanatoe_Mesto() {
        return Zanatoe_Mesto;
    }

    /**
     * @param Zanatoe_Mesto the Zanatoe_Mesto to set
     */
    public void setZanatoe_Mesto(int Zanatoe_Mesto) {
        this.Zanatoe_Mesto = Zanatoe_Mesto;
    }

    /**
     * @return the id_Sorevnovania_
     */
    public int getId_Sorevnovania_() {
        return id_Sorevnovania_;
    }

    /**
     * @param id_Sorevnovania_ the id_Sorevnovania_ to set
     */
    public void setId_Sorevnovania_(int id_Sorevnovania_) {
        this.id_Sorevnovania_ = id_Sorevnovania_;
    }

    /**
     * @return the id_Sportsmena_
     */
    public int getId_Sportsmena_() {
        return id_Sportsmena_;
    }

    /**
     * @param id_Sportsmena_ the id_Sportsmena_ to set
     */
    public void setId_Sportsmena_(int id_Sportsmena_) {
        this.id_Sportsmena_ = id_Sportsmena_;
    }



}
