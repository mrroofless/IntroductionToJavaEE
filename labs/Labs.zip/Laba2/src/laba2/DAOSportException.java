/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package laba2;

/**
 *
 * @author ilya270392
 */
class DAOSportException extends Exception {

    DAOSportException() {
        
    }
  DAOSportException(String msg) {
        super (msg);
    }


}
