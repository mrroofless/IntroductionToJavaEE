package serv;


public class ForestryDAOException extends Exception {

    
    public ForestryDAOException() {
    }


    public ForestryDAOException(String msg) {
        super(msg);
    }
}
