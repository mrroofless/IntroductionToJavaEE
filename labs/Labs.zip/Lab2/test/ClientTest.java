/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stu-ist109
 */
public class ClientTest {

    public ClientTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Client.
     */
    @Test
    public void testMain() throws Exception {
        try {
            System.out.println("main");
            String[] args = null;
            Client.main(args);
            // TODO review the generated test code and remove the default call to fail.
        } catch (DAO_ChipsException _GEN_UCE_NAME_1) {

        fail("The test case is a prototype.");
    }}

}