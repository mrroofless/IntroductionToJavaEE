package lab3;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author stu-ist109
 */
public class DAO_ChipsException extends Exception {

    DAO_ChipsException() {

    }
  DAO_ChipsException(String msg) {
        super (msg);
    }


}